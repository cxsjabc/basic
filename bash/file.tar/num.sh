#!/bin/bash

let "n = 071"
echo "n:$n"

let "n = 0x12"
echo "n:$n"

let "n=2#1101"
echo "n:$n"

