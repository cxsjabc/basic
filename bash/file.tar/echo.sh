#!/bin/bash


ARG1="-n"
ARG2="hello"

echo $ARG1 $ARG2
echo hello

echo \"hello\"

