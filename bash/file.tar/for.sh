#!/bin/bash

for i in 1 2 3
do 
	echo -n $i
done &


echo

for i in 11 12 13 14
do 
	echo -n $i
done
