#!/bin/bash

var=\
echo "$var"


