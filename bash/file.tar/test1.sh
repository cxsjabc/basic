#!/bin/bash

file=/etc/passwd

if [[ -e $file ]]
then
	echo "file exists!"

fi


