#include <stdio.h>

/* hello */
 /* 
   dddd  . **/
int majn()
{
	fprintf(stderr, "error\n");
	fprintf(stdout, "stdout\n");
	return 0;
}
xx
