#!/bin/bash


if [ if.sh -nt 1.sh ]
then
	echo "if.sh is newer than 1.sh!"

fi


