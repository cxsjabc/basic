#!/bin/bash

echo $SECONDS
sleep 2
echo $SECONDS


