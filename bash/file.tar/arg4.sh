#!/bin/bash

echo "$@"
shift
echo "$@"
shift
echo "$@"
shift
echo "$@"

shift
echo "$@"



