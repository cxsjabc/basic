#!/bin/bash

var1=1
var12=12

echo "$var12"


