#!/bin/bash


file -
