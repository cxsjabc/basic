#!/bin/bash

echo $export_value

