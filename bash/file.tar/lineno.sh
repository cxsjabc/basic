#!/bin/bash


echo hello
echo $LINENO



