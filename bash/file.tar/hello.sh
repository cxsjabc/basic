#!/bin/bash

i=5
echo 'hello'
sleep 1
echo 'xichen'
echo $AA
