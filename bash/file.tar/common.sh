#!/bin/bash

{
echo "Usage: `basename $0` $(basename $0)"
} > /dev/null 

a=" 123"
echo "|"$a"|" 
