#!/bin/bash


/bin/echo hello,xiyi
echo hello,xiyi


