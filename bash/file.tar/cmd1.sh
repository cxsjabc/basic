#!/bin/bash

a=`echo hello | tr a-z A-Z`
echo $a


