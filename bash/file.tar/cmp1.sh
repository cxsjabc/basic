#!/bin/bash

(( $1 <= $2 )) && echo "<=" || echo ">"



