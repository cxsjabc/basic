#!/bin/bash

for planet in "Mercury 36" "Earth 93"
do 
	set -- $planet
	echo "$1  $2,000,000 miles from the sun"

done


