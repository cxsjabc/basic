#!/bin/bash


cmd=$_
echo "cmd:$cmd"


