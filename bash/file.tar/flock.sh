#!/bin/bash


flock 1.sh
echo "hello"
sleep 3


