#!/bin/bash

sudo mv /usr/share/man /usr/share/man_linux_bak && sudo mv /usr/share/man_mac /usr/share/man && sudo mv /usr/share/man_linux_bak /usr/share/man_linux
