#!/bin/bash


until [ -z "$1" ]
do 
	echo "Arg: $1"
	shift
done
