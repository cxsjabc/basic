#!/bin/bash

let "a += 3"
echo $a
