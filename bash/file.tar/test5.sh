#!/bin/bash

#arg=$1

[ -n $1 ] && echo "$1 not null" || echo "$1 null"
[ -n "$1" ] && echo "$1 not null" || echo "$1 null"


[ -n $arg ] && echo "$arg not null" || echo "$arg null"
[ -n "$arg" ] && echo "$arg not null" || echo "$arg null"

