#!/bin/bash

TEMP=$(ls $1*)

echo $TEMP


