#!/bin/bash

TIMEOUT=4
read -t $TIMEOUT name

echo "name:$name"


