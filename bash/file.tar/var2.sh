#!/bin/bash

VAR2_DATA=var2_data

arch=$(`cat $VAR2_DATA`)
echo $arch


arch=$(uname)
echo $arch
