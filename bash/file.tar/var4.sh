#!/bin/bash

var="'(]\\{}\$\""

echo   $var
echo     "$var"


IFS='\'
echo $var
echo "$var"
