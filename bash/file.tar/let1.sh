#!/bin/bash


let "a=2**3"

echo "a:$a"


