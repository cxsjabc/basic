#!/bin/bash

INFO=`ls -l "$1"`
echo $INFO


