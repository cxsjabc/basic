#!/bin/bash

let "t2=((a=9,15/3))"
echo "t2:$t2, a:$a"

let "a=7,b=2,a++"
echo "a:$a"



