#include <stdio.h>

/* hello */
 /* 
   dddd  . **/
int main()
{
	fprintf(stderr, "error\n");
	fprintf(stdout, "stdout\n");
	return 0;
}
