#!/bin/bash

echo -n "What's your name?"$'\n'
read name

echo "Your name is:$name"


