#!/bin/bash

ARG=$1

if [ $ARG = "1" ]
then
	echo "1"
elif [ $ARG = "2" ] 
then
	echo "2"

else
	echo "others"

fi



