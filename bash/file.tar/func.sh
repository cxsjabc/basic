#!/bin/bash

xyz()
{
	echo "curr func:$FUNCNAME is executing..."
}

xyz

echo "curr func: $FUNCNAME"


