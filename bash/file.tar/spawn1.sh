#!/bin/bash

i=1
echo "$i instances is running..."
bash $0
echo "After bash $0"


