#!/bin/bash

a=2147483647
echo "$a"

let "a=a+1"
echo "$a"


