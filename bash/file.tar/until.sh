#!/bin/bash

val1=

until [ "$val1" = "end" ]
do
	echo "Input the value#1 (end to exit):"
	read val1

	echo "val1: #1 $val1"	
	echo
done


