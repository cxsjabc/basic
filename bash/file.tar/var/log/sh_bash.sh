#!/bin/bash

source not_exist.file
echo hello
