

cd .
cat /dev/null > messages
cat /dev/null > wtmp
echo "Logs cleaned up"
