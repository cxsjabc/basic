#!/bin/bash

set a b c
echo "$*"

echo "$-"

