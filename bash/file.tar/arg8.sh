#!/bin/bash

echo ${1#0}

echo ${PWD##*/}


