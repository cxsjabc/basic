#!/bin/bash

set a b c

echo "arg num: ${#@}, ${#*}, $#"


