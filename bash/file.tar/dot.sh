#!/bin/bash


FOLDER=`pwd`
ls_info=`ls -l`

echo "Folder: $FOLDER"
echo "LS_INFO: $ls_info"
