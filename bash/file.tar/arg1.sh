#!/bin/bash

var1="a variable word"

ls This is $var1
ls "This is $var1"
