#!/bin/bash

TMOUT=5
echo "Input a number:"
read num


echo $num


