#!/bin/bash

if [ $1 -eq 2 ] && [ $2 -eq 3 ]
then
	echo "arg1:$1, arg2:$2"

fi



