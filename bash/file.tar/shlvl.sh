#!/bin/bash

echo $SHLVL


