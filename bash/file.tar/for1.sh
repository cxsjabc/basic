#!/bin/bash

for name in maomao xiyi eyu xiaoxiong
do 
	echo "name:$name"

done

for name in "maomao" xiyi "eyu xiaoxiong"
do 
	echo "name:$name"

done

