#!/bin/bash

c=0
((c+=1))
echo "$c ((c+=1))"


