#!/bin/bash

sudo mv /usr/share/man /usr/share/man_mac_bak && sudo mv /usr/share/man_linux /usr/share/man && sudo mv /usr/share/man_mac_bak /usr/share/man_mac
