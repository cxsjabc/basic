#!/bin/bash


a="^H^H"
echo -n "abcdefg$a "
