#!/bin/bash

read i

case $i in
	"a" ) echo "a" ;;
	"b" ) echo "b" ;;
	"c" ) echo "c" ;;
	*   ) echo "others";;
esac

