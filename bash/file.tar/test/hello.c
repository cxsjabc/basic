#include <stdio.h>

int main()
{
	fprintf(stderr, "error\n");
	fprintf(stdout, "stdout\n");
	return 0;
}
